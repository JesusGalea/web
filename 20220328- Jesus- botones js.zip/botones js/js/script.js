	function ObtenerDatos(){
	var name = document.getElementById('nombre').value;
	var name2 = document.getElementById('apellidos').value;
	var age = document.getElementById('edad').value;

	alert(name + name2 + age);
} 